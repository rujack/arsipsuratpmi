<a class="btn btn-sm btn-outline-primary" href="/surat/<?php echo e($model->id); ?>"><i class="fas fa-eye"></i></a>
<a class="btn btn-sm btn-outline-warning mx-1" href="/surat/<?php echo e($model->id); ?>/edit"><i class="fas fa-edit"></i></a>

<form action="/surat/<?php echo e($model->id); ?>" method="post" class="d-inline">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-outline-danger" onclick="return confirm('are you sure ?');"><i class="fas fa-trash-alt"></i></button>
</form>
<?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/partials/actionSurat.blade.php ENDPATH**/ ?>