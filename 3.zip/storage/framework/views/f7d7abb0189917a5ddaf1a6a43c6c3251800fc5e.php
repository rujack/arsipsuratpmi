<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
    <script defer src="https://use.fontawesome.com/releases/v5.15.4/js/all.js"
        integrity="sha384-rOA1PnstxnOBLzCLMcre8ybwbTmemjzdNlILg8O7z1lUkLXozs4DHonlDtnE7fpc" crossorigin="anonymous">
    </script>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>


<body class="d-flex flex-column h-100">
    <div class="flex-shrink-o mb-3">
        <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="p-4">
            <a class="btn my-3 ms-3 fs-5 btn-outline-danger" data-bs-toggle="offcanvas" href="#offcanvasExample"
                role="button" aria-controls="offcanvasExample"><i class="fas fa-bars"></i></a>
            <div class="container">
                <?php echo $__env->yieldContent('container'); ?>
            </div>
        </section>
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script src="/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/layouts/main.blade.php ENDPATH**/ ?>