<a class="btn btn-sm btn-outline-primary me-1" href="/user/<?php echo e($model->id); ?>"><i class="fas fa-eye"></i></a>
<a class="btn btn-sm btn-outline-warning mx-1" href="/user/<?php echo e($model->id); ?>/edit"><i class="fas fa-edit"></i></a>

<form action="/user/<?php echo e($model->id); ?>" method="post" class="d-inline">
    <?php echo method_field('delete'); ?>
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-outline-danger ms-1" onclick="return confirm('are you sure ?');"><i
            class="fas fa-trash"></i></button>
</form>
<form action="/user/reset/<?php echo e($model->id); ?>" method="post" class="d-inline">
    <?php echo method_field('put'); ?>
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-outline-warning text-danger ms-1" onclick="return confirm('are you sure ?');"><i class="fas fa-undo"></i></button>
</form>
<?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/partials/actionUser.blade.php ENDPATH**/ ?>