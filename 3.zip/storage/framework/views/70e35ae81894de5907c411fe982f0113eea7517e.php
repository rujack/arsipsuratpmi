<a class="btn btn-sm btn-outline-primary" href="/surat/<?php echo e($model->id); ?>"><i class="fas fa-eye"></i></a>
<form action="/pengajuan/terima/<?php echo e($model->id); ?>" method="post" class="d-inline">
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-outline-success mx-1"><i class="fas fa-check"></i></button>
</form>
<form action="/pengajuan/tolak/<?php echo e($model->id); ?>" method="post" class="d-inline">
    <?php echo csrf_field(); ?>
    <button class="btn btn-sm btn-outline-danger"><i class="fas fa-archive"></i></button>
</form>
<?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/partials/actionPengajuan.blade.php ENDPATH**/ ?>