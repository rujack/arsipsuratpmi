<div class="col-2"><a class="btn btn-sm bg-primary text-white"
        href="/surat/<?php echo e(request()->path() . '/' . $model->id); ?>">Lihat</a></div>
<div class="col-2"><a class="btn btn-sm bg-warning text-white" href="/surat/<?php echo e($model->id); ?>/edit">Edit</a></div>
<div class="col-2">
    <form action="/surat/<?php echo e($model->id); ?>" method="post" class="d-inline">
        <?php echo method_field('delete'); ?>
        <?php echo csrf_field(); ?>
        <button class="btn btn-sm bg-danger text-white" onclick="return confirm('are you sure ?');">Hapus</button>
    </form>
</div>
<?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/partials/action.blade.php ENDPATH**/ ?>