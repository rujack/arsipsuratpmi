<?php $__env->startSection('container'); ?>
    <div class="row">
        <div class="col-12 bg-danger text-white p-3">
            <div class="row">
                <div class="col">
                    <h3 class="text-center text-light">Lihat User</h3>
                </div>
            </div>
        </div>
        <div class="col p-0">
            <div class="card pt-3 bg-light">
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12 col-md-6">
                            <div class="form-floating mb-3 ">
                                <input type="text" class="form-control shadow-sm"
                                    placeholder="No. Surat" value="<?php echo e($user->id_anggota); ?>" readonly />
                                <label class="form-label">Id Anggota</label>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="form-floating mb-3 ">
                                <input type="text" class="form-control shadow-sm" value="<?php echo e($user->name); ?>" readonly />
                                <label class="form-label">Nama</label>

                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="form-floating mb-3 ">
                                <input type="text" class="form-control shadow-sm" value="<?php echo e($user->email); ?>" readonly />
                                <label class="form-label">Email</label>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6">
                            <div class="form-floating mb-3 ">
                                <input type="text" class="form-control shadow-sm" value="<?php echo e($user->role); ?>" readonly />
                                <label class="form-label">Level</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/user/view.blade.php ENDPATH**/ ?>