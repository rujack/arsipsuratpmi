<?php $__env->startSection('container'); ?>
    
    <div class="row">
        <div class="col-12 bg-danger text-white p-3">
            <div class="row">
                <div class="col">
                    <h3>Surat</h3>
                </div>
                <div class="col text-end"><a href="/surat/create" class="btn btn-primary btn-lg px-5">Tambah</a></div>
            </div>
        </div>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success mt-3" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="col">
            <table class="table">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">No. Surat</th>
                        <th scope="col">Perihal</th>
                        <th scope="col">Tipe Surat</th>
                        <th scope="col">Pengirim</th>
                        <th scope="col">Penerima</th>
                        <th scope="col">File</th>
                        <th scope="col" class="w-25">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $surats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $surat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($loop->iteration); ?></th>
                            <td><?php echo e($surat->no_surat); ?></td>
                            <td><?php echo e($surat->perihal); ?></td>
                            <td><?php echo e($surat->tipe_surat); ?></td>
                            <td><?php echo e($surat->pengirim); ?></td>
                            <td><?php echo e($surat->penerima); ?></td>
                            <td><?php echo e($surat->file); ?></td>
                            <td>
                                <div class="row">
                                    <div class="col-2"><a class="btn btn-sm bg-primary text-white"
                                            href="/surat/<?php echo e($surat->id); ?>">Lihat</a></div>
                                    <div class="col-2">
                                        <form action="/persetujuan/terima/<?php echo e($surat->id); ?>" method="post"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm bg-warning text-white">Terima</button>
                                        </form>
                                    </div>
                                    <div class="col-2">
                                        <form action="/persetujuan/tolak/<?php echo e($surat->id); ?>" method="post"
                                            class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm bg-danger text-white">Tolak</button>
                                        </form>
                                    </div>
                                    
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/persetujuan.blade.php ENDPATH**/ ?>