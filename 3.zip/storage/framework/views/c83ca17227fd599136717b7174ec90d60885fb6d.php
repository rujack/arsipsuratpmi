<?php $__env->startSection('container'); ?>
<div class="row">
    <div class="col-12 bg-danger text-white p-3">
      <div class="row">
        <div class="col">
          <h3>Surat</h3>
        </div>
        <div class="col text-end"><a href="/suratInput.html" class="btn btn-primary btn-lg px-5">Tambah</a></div>
      </div>
    </div>
    <div class="col">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">First</th>
            <th scope="col">Last</th>
            <th scope="col">Handle</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
            <td>@mdo</td>
            <td>
              <div class="row">
                <div class="col-2"><a class="btn btn-sm bg-primary">Lihat</a></div>
                <div class="col-2"><a class="btn btn-sm bg-warning">Edit</a></div>
                <div class="col-2"><a class="btn btn-sm bg-danger">Hapus</a></div>
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>@fat</td>
            <td>
              <div class="row">
                <div class="col-2"><a class="btn btn-sm bg-primary">Lihat</a></div>
                <div class="col-2"><a class="btn btn-sm bg-warning">Edit</a></div>
                <div class="col-2"><a class="btn btn-sm bg-danger">Hapus</a></div>
              </div>
            </td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td colspan="2">Larry the Bird</td>
            <td>@twitter</td>
            <td>
              <div class="row">
                <div class="col-2"><a class="btn btn-sm bg-primary">Lihat</a></div>
                <div class="col-2"><a class="btn btn-sm bg-warning">Edit</a></div>
                <div class="col-2"><a class="btn btn-sm bg-danger">Hapus</a></div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/surat.blade.php ENDPATH**/ ?>