<!-- Footer -->
<footer class="text-center text-lg-start bg-white text-muted border-top border-3 border-danger mt-auto footer">
    <!-- Section: Social media -->
    <!-- Section: Social media -->

    <!-- Section: Links  -->

        <div class="container text-center text-md-start mt-5">
            <!-- Grid row -->
            <div class="row mt-3">
                <!-- Grid column -->
                <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                    <!-- Content -->
                    <h6 class="text-uppercase fw-bold mb-4">MARKAS PMI KOTA PASURUAN </h6>
                    <p class=" text-nowrap">
                        Jl.dr. Wahidin Sudiro Husodo No.119
                    </p>
                    <p class="text-nowrap">
                        67117 Kota Pasuruan
                    </p>
                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                    <!-- Links -->
                    <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                    <p class=" text-nowrap">
                        <i class="fas fa-envelope me-3 text-grayish"></i>
                        pmikotapasuruan2021@gmail.com
                    </p>
                    <p><i class="fas fa-phone me-3 text-grayish"></i> (0343) 5642143</p>
                </div>
                <!-- Grid column -->
            </div>
            <!-- Grid row -->
        </div>
    <!-- Section: Links  -->

    <!-- Copyright -->
    <div class="text-center p-4 bg-light">
        © 2022 Copyright: Team Task SLayer
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
<?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/partials/footer.blade.php ENDPATH**/ ?>