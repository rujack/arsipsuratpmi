<?php $__env->startSection('container'); ?>
    <section class="h-100 gradient-form" style="background-color: #eee;">
        <div class="container py-5 h-100">
            <div class="row d-flex justify-content-center align-items-center h-100">
                <div class="col-xl-10">
                    <div class="card rounded-3 text-black shadow border-0">
                        <div class="row g-0">
                            <div class="col-lg-4 d-none d-lg-block m-auto ">
                                <div class="text-center px-1 py-4 p-md-2 mx-md-4">
                                    <img src="/img/pmi.png" alt="Logo PMI" class="w-100">
                                </div>
                            </div>
                            <div class="col-lg-8 py-lg-5">
                                <div class="card-body p-5 mx-md-3">
                                    <div class="text-center">
                                        <img src="/img/logopmi.png" style="width: 130px;" alt="logo"
                                            class="d-none d-md-block d-sm-block d-lg-none  m-auto">
                                        <img src="/img/logopmi.png" style="width: 130px;" alt="logo"
                                            class="d-block d-sm-none m-auto">
                                        <h4 class="mt-1 mb-5 pb-1 text-uppercase"><span class="d-none d-lg-block">PMI</span>
                                            Kota Pasuruan</h4>
                                    </div>
                                    <?php if(session()->has('loginError')): ?>
                                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                            <?php echo e(session('loginError')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                    <?php endif; ?>

                                    <form action="/login" method="post">
                                        <?php echo csrf_field(); ?>
                                        <p>Please login to your account</p>

                                        <div class="form-floating mb-4 ">
                                            <input type="email" id="email"
                                                class="form-control shadow-sm <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="email" placeholder="email address" />
                                            <label class="form-label" for="email">Email</label>
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="form-floating mb-4">
                                            <input type="password" id="password"
                                                class="form-control shadow-sm <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                name="password" placeholder="Password" />
                                            <label class="form-label" for="password">Password</label>
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="invalid-feedback">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="text-center pt-1 mb-5 pb-1 col-lg-5 col-md-6 mx-auto">
                                            <button class="btn btn-outline-danger w-100 btn-block fa-lg mb-3 shadow"
                                                type="submit">Log
                                                in</button>
                                        </div>

                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sandal/Documents/Laravel/tes/resources/views/login.blade.php ENDPATH**/ ?>